# python-oc 
Python Module for Oracle Public Cloud that wraps the REST APIs that provide access to the various Oracle Public Cloud / 
Oracle Public Cloud Machine services. The module currently supports the following services:
- Oracle Compute Cloud Server
- Oracle Storage Cloud Server

## Installation
```bash
tar -xvf python-oc.tar
cd oc
python setup.py install
```

## Requirements
- python json module 
- python requests module

## Usage

## Development

## Contributing

Bug reports, enhancements and pull requests are welcome on [python-oc/issues](https://orahub.oraclecorp.com/cloud-tools-ateam/python-oc/issues)